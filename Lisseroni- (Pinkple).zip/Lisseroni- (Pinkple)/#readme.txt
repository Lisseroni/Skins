If you want the Back animation to play smoothly, you should have the "animationframerate" option
set at or beyond 12 in your skin.ini. It might play a bit oddly otherwise.
 